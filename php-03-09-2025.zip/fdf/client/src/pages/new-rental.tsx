import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { FileUpload } from "@/components/ui/file-upload";
import { DocumentViewer } from "@/components/ui/document-viewer";
import { Plus, ArrowLeft, Calendar, Package, Truck, FileText, Camera, Clipboard } from "lucide-react";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";

const rentalSchema = z.object({
  supplierId: z.string().min(1, "Fornecedor é obrigatório"),
  productId: z.string().min(1, "Produto é obrigatório"),
  quantity: z.number().min(1, "Quantidade deve ser no mínimo 1"),
  dailyRate: z.number().min(0.01, "Valor diário deve ser maior que zero"),
  startDate: z.string().min(1, "Data de início é obrigatória"),
  endDate: z.string().min(1, "Data de fim é obrigatória"),
  notes: z.string().optional(),
});

type RentalForm = z.infer<typeof rentalSchema>;

interface FileWithPreview extends File {
  preview?: string;
  id: string;
}

export default function NewRental() {
  const [, setLocation] = useLocation();
  const [contractDocuments, setContractDocuments] = useState<FileWithPreview[]>([]);
  const [equipmentPhotos, setEquipmentPhotos] = useState<FileWithPreview[]>([]);
  const [additionalDocs, setAdditionalDocs] = useState<FileWithPreview[]>([]);
  const [viewerFile, setViewerFile] = useState<{ name: string; type: string; url: string; } | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors, isSubmitting }
  } = useForm<RentalForm>({
    resolver: zodResolver(rentalSchema),
    defaultValues: {
      quantity: 1,
      dailyRate: 0,
      startDate: format(new Date(), "yyyy-MM-dd"),
      endDate: format(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), "yyyy-MM-dd"),
    }
  });

  const { data: suppliers, isLoading: loadingSuppliers } = useQuery({
    queryKey: ["/api/suppliers"],
    queryFn: api.getSuppliers,
  });

  const { data: products, isLoading: loadingProducts } = useQuery({
    queryKey: ["/api/products"],
    queryFn: api.getProducts,
  });

  const createRentalMutation = useMutation({
    mutationFn: api.createRental,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rentals"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({
        title: "Sucesso",
        description: "Aluguel criado com sucesso",
      });
      setLocation("/rentals");
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Falha ao criar aluguel",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: RentalForm) => {
    createRentalMutation.mutate(data);
  };

  const selectedSupplierId = watch("supplierId");
  const selectedProductId = watch("productId");
  const quantity = watch("quantity");
  const dailyRate = watch("dailyRate");
  const startDate = watch("startDate");
  const endDate = watch("endDate");

  // Calcular total estimado
  const calculateTotal = () => {
    if (!startDate || !endDate || !dailyRate || !quantity) return 0;
    const start = new Date(startDate);
    const end = new Date(endDate);
    const days = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    return (dailyRate * quantity * days).toFixed(2);
  };

  if (loadingSuppliers || loadingProducts) {
    return (
      <MainLayout 
        title="Novo Aluguel" 
        subtitle="Crie uma nova locação de equipamento"
      >
        <div className="max-w-2xl mx-auto space-y-6">
          <Card>
            <CardContent className="p-6">
              <div className="space-y-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="space-y-2">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-10 w-full" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout 
      title="Novo Aluguel" 
      subtitle="Crie uma nova locação de equipamento"
    >
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center space-x-4">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setLocation("/rentals")}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar para Equipamentos Alugados
          </Button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)}>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Plus className="h-5 w-5" />
                <span>Informações do Aluguel</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Fornecedor */}
              <div className="space-y-2">
                <Label htmlFor="supplierId" className="flex items-center space-x-2">
                  <Truck className="h-4 w-4" />
                  <span>Fornecedor</span>
                </Label>
                <Select onValueChange={(value) => setValue("supplierId", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um fornecedor" />
                  </SelectTrigger>
                  <SelectContent>
                    {suppliers?.map((supplier: any) => (
                      <SelectItem key={supplier.id} value={supplier.id}>
                        {supplier.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.supplierId && (
                  <p className="text-sm text-destructive">{errors.supplierId.message}</p>
                )}
              </div>

              {/* Produto */}
              <div className="space-y-2">
                <Label htmlFor="productId" className="flex items-center space-x-2">
                  <Package className="h-4 w-4" />
                  <span>Produto</span>
                </Label>
                <Select onValueChange={(value) => setValue("productId", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um produto" />
                  </SelectTrigger>
                  <SelectContent>
                    {products?.map((product: any) => (
                      <SelectItem key={product.id} value={product.id}>
                        {product.name} - {product.model}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.productId && (
                  <p className="text-sm text-destructive">{errors.productId.message}</p>
                )}
              </div>

              {/* Quantidade e Valor Diário */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantidade</Label>
                  <Input
                    id="quantity"
                    type="number"
                    min="1"
                    {...register("quantity", { valueAsNumber: true })}
                  />
                  {errors.quantity && (
                    <p className="text-sm text-destructive">{errors.quantity.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dailyRate">Valor Diário (R$)</Label>
                  <Input
                    id="dailyRate"
                    type="number"
                    step="0.01"
                    min="0.01"
                    {...register("dailyRate", { valueAsNumber: true })}
                  />
                  {errors.dailyRate && (
                    <p className="text-sm text-destructive">{errors.dailyRate.message}</p>
                  )}
                </div>
              </div>

              {/* Datas */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="startDate" className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4" />
                    <span>Data de Início</span>
                  </Label>
                  <Input
                    id="startDate"
                    type="date"
                    {...register("startDate")}
                  />
                  {errors.startDate && (
                    <p className="text-sm text-destructive">{errors.startDate.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="endDate">Data de Fim</Label>
                  <Input
                    id="endDate"
                    type="date"
                    {...register("endDate")}
                  />
                  {errors.endDate && (
                    <p className="text-sm text-destructive">{errors.endDate.message}</p>
                  )}
                </div>
              </div>

              {/* Observações */}
              <div className="space-y-2">
                <Label htmlFor="notes">Observações (opcional)</Label>
                <Textarea
                  id="notes"
                  placeholder="Adicione observações sobre este aluguel..."
                  {...register("notes")}
                />
              </div>

              {/* Seção de Documentação */}
              <Card className="border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-primary">
                    <FileText className="h-5 w-5" />
                    <span>Documentação do Aluguel</span>
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Anexe todos os documentos relacionados ao aluguel para manter um registro completo
                  </p>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Documentos do Contrato */}
                  <div>
                    <div className="flex items-center space-x-2 mb-3">
                      <Clipboard className="h-4 w-4 text-blue-600" />
                      <span className="font-medium">Contrato e Termos</span>
                    </div>
                    <FileUpload
                      label=""
                      description="Contrato de aluguel, termos de uso, condições especiais"
                      accept=".pdf,.doc,.docx"
                      maxFiles={5}
                      onFilesChange={setContractDocuments}
                      value={contractDocuments}
                    />
                  </div>

                  {/* Fotos do Equipamento */}
                  <div>
                    <div className="flex items-center space-x-2 mb-3">
                      <Camera className="h-4 w-4 text-green-600" />
                      <span className="font-medium">Fotos do Equipamento</span>
                    </div>
                    <FileUpload
                      label=""
                      description="Fotos do estado do equipamento antes do aluguel"
                      accept="image/*"
                      maxFiles={10}
                      onFilesChange={setEquipmentPhotos}
                      value={equipmentPhotos}
                    />
                  </div>

                  {/* Documentos Adicionais */}
                  <div>
                    <div className="flex items-center space-x-2 mb-3">
                      <FileText className="h-4 w-4 text-purple-600" />
                      <span className="font-medium">Documentos Adicionais</span>
                    </div>
                    <FileUpload
                      label=""
                      description="Manuais, especificações técnicas, certificados, etc."
                      accept=".pdf,.doc,.docx,image/*"
                      maxFiles={8}
                      onFilesChange={setAdditionalDocs}
                      value={additionalDocs}
                    />
                  </div>

                  {/* Resumo dos Documentos */}
                  {(contractDocuments.length > 0 || equipmentPhotos.length > 0 || additionalDocs.length > 0) && (
                    <div className="mt-6 p-4 bg-muted/50 rounded-lg">
                      <h4 className="font-semibold mb-2">Resumo da Documentação</h4>
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Contratos e Termos:</p>
                          <p className="font-medium">{contractDocuments.length} arquivo(s)</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Fotos do Equipamento:</p>
                          <p className="font-medium">{equipmentPhotos.length} foto(s)</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Documentos Adicionais:</p>
                          <p className="font-medium">{additionalDocs.length} arquivo(s)</p>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Resumo */}
              {quantity > 0 && dailyRate > 0 && startDate && endDate && (
                <Card className="bg-muted/50">
                  <CardContent className="p-4">
                    <div className="space-y-2">
                      <h3 className="font-semibold">Resumo do Aluguel</h3>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Período:</p>
                          <p>{format(new Date(startDate), "dd/MM/yyyy")} - {format(new Date(endDate), "dd/MM/yyyy")}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Total Estimado:</p>
                          <p className="font-semibold text-lg">R$ {calculateTotal()}</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Botões */}
              <div className="flex justify-end space-x-4 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setLocation("/rentals")}
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Criando..." : "Criar Aluguel"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </form>

        {/* Visualizador de Documentos */}
        <DocumentViewer
          isOpen={viewerFile !== null}
          onClose={() => setViewerFile(null)}
          file={viewerFile}
        />
      </div>
    </MainLayout>
  );
}
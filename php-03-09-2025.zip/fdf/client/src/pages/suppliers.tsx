import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Search, Truck, Phone, Mail, MapPin } from "lucide-react";
import { api } from "@/lib/api";
import { Supplier } from "@/types";

export default function Suppliers() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSupplier, setSelectedSupplier] = useState<string | null>(null);

  const { data: suppliers, isLoading } = useQuery<Supplier[]>({
    queryKey: ["/api/suppliers"],
    queryFn: api.getSuppliers,
  });

  const filteredSuppliers = suppliers?.filter(supplier =>
    supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    supplier.contactPerson?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    supplier.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const activeSuppliers = suppliers?.filter(s => s.isActive) || [];

  if (isLoading) {
    return (
      <MainLayout 
        title="Fornecedores" 
        subtitle="Gerencie seus fornecedores de equipamentos"
      >
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-10 w-32" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Array.from({ length: 2 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <Skeleton className="h-16 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="grid gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-20 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout 
      title="Fornecedores" 
      subtitle="Gerencie seus fornecedores de equipamentos"
    >
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold" data-testid="text-suppliers-title">Suppliers</h1>
            <p className="text-muted-foreground" data-testid="text-suppliers-subtitle">
              Manage your equipment suppliers and contacts
            </p>
          </div>
          <Button data-testid="button-add-supplier">
            <Plus className="mr-2 h-4 w-4" />
            Add Supplier
          </Button>
        </div>

        {/* Supplier Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card data-testid="card-total-suppliers">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Truck className="text-blue-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Suppliers</p>
                  <p className="text-xl font-bold">{suppliers?.length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card data-testid="card-active-suppliers">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                  <Truck className="text-green-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Active Suppliers</p>
                  <p className="text-xl font-bold text-green-600">{activeSuppliers.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Input
            type="search"
            placeholder="Search suppliers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pr-10"
            data-testid="input-search-suppliers"
          />
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        </div>

        {/* Suppliers List */}
        <div className="grid gap-4">
          {filteredSuppliers?.length === 0 && searchTerm ? (
            <Card data-testid="no-search-results">
              <CardContent className="p-8 text-center">
                <Search className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
                <h3 className="text-sm font-medium">No suppliers found</h3>
                <p className="text-xs text-muted-foreground">
                  Try adjusting your search terms
                </p>
              </CardContent>
            </Card>
          ) : suppliers?.length === 0 ? (
            <Card data-testid="empty-suppliers">
              <CardContent className="p-12 text-center">
                <Truck className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No suppliers added</h3>
                <p className="text-muted-foreground mb-4">
                  Add suppliers you rent equipment from
                </p>
                <Button data-testid="button-first-supplier">
                  <Plus className="mr-2 h-4 w-4" />
                  Add First Supplier
                </Button>
              </CardContent>
            </Card>
          ) : (
            filteredSuppliers?.map((supplier) => (
              <Card 
                key={supplier.id} 
                className="hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => setSelectedSupplier(selectedSupplier === supplier.id ? null : supplier.id)}
                data-testid={`card-supplier-${supplier.id}`}
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-4 flex-1">
                      <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center">
                        <Truck className="text-secondary-foreground" size={20} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-lg font-semibold" data-testid={`text-supplier-name-${supplier.id}`}>
                            {supplier.name}
                          </h3>
                          <Badge variant={supplier.isActive ? "default" : "secondary"}>
                            {supplier.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center space-x-2">
                            <Phone size={14} />
                            <span data-testid={`text-phone-${supplier.id}`}>
                              {supplier.phone || "No phone"}
                            </span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Mail size={14} />
                            <span data-testid={`text-email-${supplier.id}`}>
                              {supplier.email || "No email"}
                            </span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <MapPin size={14} />
                            <span data-testid={`text-address-${supplier.id}`}>
                              {supplier.address || "No address"}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex space-x-2 ml-4">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={(e) => e.stopPropagation()}
                        data-testid={`button-edit-${supplier.id}`}
                      >
                        Edit
                      </Button>
                    </div>
                  </div>
                  
                  {selectedSupplier === supplier.id && (
                    <div className="mt-4 pt-4 border-t border-border">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="font-medium mb-2">Contact Information</p>
                          <div className="space-y-1">
                            <p><span className="font-medium">Contact Person:</span> {supplier.contactPerson || "N/A"}</p>
                            <p><span className="font-medium">Email:</span> {supplier.email || "N/A"}</p>
                            <p><span className="font-medium">Phone:</span> {supplier.phone || "N/A"}</p>
                          </div>
                        </div>
                        <div>
                          <p className="font-medium mb-2">Address</p>
                          <p className="text-muted-foreground">
                            {supplier.address || "No address provided"}
                          </p>
                        </div>
                      </div>
                      {supplier.notes && (
                        <div className="mt-4">
                          <p className="font-medium mb-1">Notes</p>
                          <p className="text-muted-foreground text-sm">{supplier.notes}</p>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </MainLayout>
  );
}

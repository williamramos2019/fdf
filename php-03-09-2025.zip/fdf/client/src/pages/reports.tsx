import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, DollarSign, TrendingUp, FileText, Download, Package, Handshake } from "lucide-react";
import { api } from "@/lib/api";
import { format } from "date-fns";

export default function Reports() {
  const [expensePeriod, setExpensePeriod] = useState("6months");

  const { data: expenseReport, isLoading: expenseLoading } = useQuery({
    queryKey: ["/api/reports/expenses", expensePeriod],
    queryFn: () => api.getExpenseReport(expensePeriod),
  });

  const { data: inventoryReport, isLoading: inventoryLoading } = useQuery({
    queryKey: ["/api/reports/inventory"],
    queryFn: api.getInventoryReport,
  });

  const { data: dashboardStats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    queryFn: api.getDashboardStats,
  });

  return (
    <MainLayout 
      title="Relatórios" 
      subtitle="Acompanhe suas despesas com locações e insights de inventário"
    >
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold" data-testid="text-reports-title">Relatórios de Locações</h1>
            <p className="text-muted-foreground" data-testid="text-reports-subtitle">
              Acompanhe suas despesas com locações e insights de inventário
            </p>
          </div>
          <Button variant="outline" data-testid="button-export-reports">
            <Download className="mr-2 h-4 w-4" />
            Exportar Relatórios
          </Button>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card data-testid="card-total-expense">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="text-red-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Despesas Totais</p>
                  <p className="text-xl font-bold">
                    R$ {expenseReport?.totalExpenses || "0"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card data-testid="card-active-rentals-count">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Handshake className="text-blue-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Locações Ativas</p>
                  <p className="text-xl font-bold">{dashboardStats?.activeRentals || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card data-testid="card-inventory-value">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                  <Package className="text-green-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Inventory Value</p>
                  <p className="text-xl font-bold">
                    ${inventoryReport?.totalValue || "0"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card data-testid="card-avg-daily-cost">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="text-purple-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Avg. Daily Cost</p>
                  <p className="text-xl font-bold">
                    ${expenseReport?.avgDailyCost || "0"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Expense Report */}
        <Card data-testid="card-expense-report">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center space-x-2">
                <DollarSign className="h-5 w-5" />
                <span>Expense Report</span>
              </CardTitle>
              <Select value={expensePeriod} onValueChange={setExpensePeriod}>
                <SelectTrigger className="w-40" data-testid="select-expense-period">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3months">Last 3 months</SelectItem>
                  <SelectItem value="6months">Last 6 months</SelectItem>
                  <SelectItem value="12months">Last 12 months</SelectItem>
                  <SelectItem value="year">This year</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            {expenseLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-64 w-full" />
              </div>
            ) : (
              <div className="space-y-6">
                {/* Summary */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-muted/30 rounded-lg">
                  <div data-testid="expense-summary-total">
                    <p className="text-sm text-muted-foreground">Total Spent</p>
                    <p className="text-2xl font-bold">${expenseReport?.totalExpenses || "0"}</p>
                  </div>
                  <div data-testid="expense-summary-avg">
                    <p className="text-sm text-muted-foreground">Average per Month</p>
                    <p className="text-2xl font-bold">${expenseReport?.avgMonthlyExpense || "0"}</p>
                  </div>
                  <div data-testid="expense-summary-trend">
                    <p className="text-sm text-muted-foreground">Trend</p>
                    <p className="text-2xl font-bold text-green-600">
                      {expenseReport?.trend || "+0%"}
                    </p>
                  </div>
                </div>

                {/* Chart */}
                <div className="h-64 flex items-end justify-between space-x-2" data-testid="expense-chart">
                  {expenseReport?.chartData?.length > 0 ? (
                    expenseReport.chartData.map((item: any, index: number) => {
                      const maxAmount = Math.max(...expenseReport.chartData.map((d: any) => d.amount));
                      const height = Math.max((item.amount / maxAmount) * 200, 10);
                      const chartColors = ["chart-1", "chart-2", "chart-3", "chart-4", "chart-5", "primary"];
                      const colorClass = chartColors[index % chartColors.length];

                      return (
                        <div key={item.month} className="flex flex-col items-center space-y-2 flex-1">
                          <div 
                            className={`w-full max-w-12 bg-${colorClass} rounded-t`}
                            style={{ height: `${height}px` }}
                            data-testid={`expense-bar-${item.month}`}
                          />
                          <span className="text-xs text-muted-foreground">{item.month}</span>
                          <span className="text-xs font-medium">${(item.amount / 1000).toFixed(1)}k</span>
                        </div>
                      );
                    })
                  ) : (
                    <div className="w-full text-center text-muted-foreground">
                      No expense data available
                    </div>
                  )}
                </div>

                {/* Top Suppliers by Expense */}
                {expenseReport?.topSuppliers?.length > 0 && (
                  <div data-testid="top-suppliers-section">
                    <h3 className="text-lg font-semibold mb-3">Top Suppliers by Expense</h3>
                    <div className="space-y-2">
                      {expenseReport.topSuppliers.map((supplier: any, index: number) => (
                        <div 
                          key={supplier.id} 
                          className="flex items-center justify-between p-3 bg-muted/30 rounded-lg"
                          data-testid={`top-supplier-${index}`}
                        >
                          <div className="flex items-center space-x-3">
                            <span className="w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xs">
                              {index + 1}
                            </span>
                            <span className="font-medium">{supplier.name}</span>
                          </div>
                          <span className="font-bold">${supplier.totalSpent}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Inventory Report */}
        <Card data-testid="card-inventory-report">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Package className="h-5 w-5" />
              <span>Inventory Report</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {inventoryLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-32 w-full" />
              </div>
            ) : (
              <div className="space-y-6">
                {/* Inventory Summary */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-muted/30 rounded-lg">
                  <div data-testid="inventory-total-items">
                    <p className="text-sm text-muted-foreground">Total Items</p>
                    <p className="text-xl font-bold">{inventoryReport?.totalItems || 0}</p>
                  </div>
                  <div data-testid="inventory-total-value">
                    <p className="text-sm text-muted-foreground">Total Value</p>
                    <p className="text-xl font-bold">${inventoryReport?.totalValue || "0"}</p>
                  </div>
                  <div data-testid="inventory-low-stock">
                    <p className="text-sm text-muted-foreground">Low Stock Items</p>
                    <p className="text-xl font-bold text-yellow-600">
                      {inventoryReport?.lowStockItems || 0}
                    </p>
                  </div>
                  <div data-testid="inventory-categories">
                    <p className="text-sm text-muted-foreground">Categories</p>
                    <p className="text-xl font-bold">{inventoryReport?.totalCategories || 0}</p>
                  </div>
                </div>

                {/* Low Stock Alert */}
                {inventoryReport?.lowStockList?.length > 0 && (
                  <div data-testid="low-stock-alert">
                    <h3 className="text-lg font-semibold mb-3 flex items-center space-x-2">
                      <span>Low Stock Items</span>
                      <span className="text-sm bg-yellow-100 text-yellow-800 px-2 py-1 rounded">
                        {inventoryReport.lowStockList.length} items
                      </span>
                    </h3>
                    <div className="space-y-2">
                      {inventoryReport.lowStockList.slice(0, 5).map((item: any, index: number) => (
                        <div 
                          key={item.id} 
                          className="flex items-center justify-between p-3 border border-yellow-200 bg-yellow-50 rounded-lg"
                          data-testid={`low-stock-item-${index}`}
                        >
                          <div>
                            <p className="font-medium">{item.name}</p>
                            <p className="text-sm text-muted-foreground">
                              Current: {item.currentStock} | Minimum: {item.minStock}
                            </p>
                          </div>
                          <span className="text-yellow-700 font-semibold">
                            {item.currentStock} left
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Category Breakdown */}
                {inventoryReport?.categoryBreakdown?.length > 0 && (
                  <div data-testid="category-breakdown">
                    <h3 className="text-lg font-semibold mb-3">Inventory by Category</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {inventoryReport.categoryBreakdown.map((category: any, index: number) => (
                        <div 
                          key={category.id} 
                          className="p-4 border rounded-lg"
                          data-testid={`category-breakdown-${index}`}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium">{category.name}</span>
                            <span className="text-sm text-muted-foreground">
                              {category.itemCount} items
                            </span>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Value: ${category.totalValue || "0"}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Export Options */}
        <Card data-testid="card-export-options">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileText className="h-5 w-5" />
              <span>Export Options</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button variant="outline" className="justify-start" data-testid="button-export-expenses">
                <Calendar className="mr-2 h-4 w-4" />
                Export Expense Report
              </Button>
              <Button variant="outline" className="justify-start" data-testid="button-export-inventory">
                <Package className="mr-2 h-4 w-4" />
                Export Inventory Report
              </Button>
              <Button variant="outline" className="justify-start" data-testid="button-export-rentals">
                <Handshake className="mr-2 h-4 w-4" />
                Export Rental History
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Calendar, DollarSign, Package, ArrowLeft, ChartLine } from "lucide-react";
import { useLocation } from "wouter";
import { api } from "@/lib/api";
import { RentalWithDetails } from "@/types";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

export default function Rentals() {
  const [selectedRental, setSelectedRental] = useState<string | null>(null);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: rentals, isLoading } = useQuery<RentalWithDetails[]>({
    queryKey: ["/api/rentals"],
    queryFn: api.getRentals,
  });

  const returnRentalMutation = useMutation({
    mutationFn: (rentalId: string) => api.returnRental(rentalId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rentals"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({
        title: "Sucesso",
        description: "Equipamento devolvido com sucesso",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Falha ao devolver equipamento",
        variant: "destructive",
      });
    },
  });

  const getStatusBadge = (status: string, endDate: string) => {
    const now = new Date();
    const due = new Date(endDate);
    const isOverdue = now > due && status === "active";
    const isDueSoon = due.getTime() - now.getTime() < 24 * 60 * 60 * 1000 && status === "active";

    if (isOverdue) {
      return { variant: "destructive" as const, text: "Atrasado", className: "bg-red-100 text-red-800" };
    }
    if (isDueSoon) {
      return { variant: "secondary" as const, text: "Vence Hoje", className: "bg-yellow-100 text-yellow-800" };
    }
    if (status === "returned") {
      return { variant: "outline" as const, text: "Devolvido", className: "bg-gray-100 text-gray-800" };
    }
    return { variant: "default" as const, text: "Ativo", className: "bg-green-100 text-green-800" };
  };

  const calculateTotalCost = (rental: RentalWithDetails) => {
    const start = new Date(rental.startDate);
    const end = rental.returnedDate ? new Date(rental.returnedDate) : new Date(rental.endDate);
    const days = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    return (parseFloat(rental.dailyRate) * days * rental.quantity).toFixed(2);
  };

  if (isLoading) {
    return (
      <MainLayout 
        title="Equipamentos Alugados" 
        subtitle="Gerencie seus equipamentos alugados de fornecedores"
      >
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-10 w-32" />
          </div>
          <div className="grid gap-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-4">
                      <Skeleton className="w-12 h-12 rounded" />
                      <div>
                        <Skeleton className="h-5 w-32 mb-2" />
                        <Skeleton className="h-4 w-24" />
                      </div>
                    </div>
                    <Skeleton className="h-6 w-16 rounded-full" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </MainLayout>
    );
  }

  const activeRentals = rentals?.filter(r => r.status === "active") || [];
  const overdueRentals = activeRentals.filter(r => new Date() > new Date(r.endDate));
  const dueSoonRentals = activeRentals.filter(r => {
    const now = new Date();
    const due = new Date(r.endDate);
    return due.getTime() - now.getTime() < 24 * 60 * 60 * 1000 && due.getTime() > now.getTime();
  });

  return (
    <MainLayout 
      title="Equipamentos Alugados" 
      subtitle="Gerencie seus equipamentos alugados de fornecedores"
    >
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold" data-testid="text-rentals-title">Equipamentos Alugados</h1>
            <p className="text-muted-foreground" data-testid="text-rentals-subtitle">
              Gerencie equipamentos alugados de fornecedores
            </p>
          </div>
          <div className="flex space-x-2">
            <Button onClick={() => setLocation("/rentals/new")} data-testid="button-new-rental">
              <Plus className="mr-2 h-4 w-4" />
              Novo Aluguel
            </Button>
            <Button variant="outline" onClick={() => setLocation("/rentals/reports")}>
              <ChartLine className="mr-2 h-4 w-4" />
              Relatórios
            </Button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card data-testid="card-active-count">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Package className="text-blue-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Ativos</p>
                  <p className="text-xl font-bold">{activeRentals.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card data-testid="card-overdue-count">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-red-100 rounded-lg flex items-center justify-center">
                  <Calendar className="text-red-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Atrasados</p>
                  <p className="text-xl font-bold text-red-600">{overdueRentals.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card data-testid="card-due-soon-count">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="text-yellow-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Vencem Hoje</p>
                  <p className="text-xl font-bold text-yellow-600">{dueSoonRentals.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Rentals List */}
        <div className="grid gap-4">
          {rentals?.length === 0 ? (
            <Card data-testid="empty-rentals">
              <CardContent className="p-12 text-center">
                <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhum equipamento alugado</h3>
                <p className="text-muted-foreground mb-4">
                  Comece alugando equipamentos de seus fornecedores
                </p>
                <Button onClick={() => setLocation("/rentals/new")} data-testid="button-first-rental">
                  <Plus className="mr-2 h-4 w-4" />
                  Criar Primeiro Aluguel
                </Button>
              </CardContent>
            </Card>
          ) : (
            rentals?.map((rental) => {
              const statusBadge = getStatusBadge(rental.status, rental.endDate);
              const totalCost = calculateTotalCost(rental);

              return (
                <Card 
                  key={rental.id} 
                  className="hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => setSelectedRental(selectedRental === rental.id ? null : rental.id)}
                  data-testid={`card-rental-${rental.id}`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-4 flex-1">
                        <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center">
                          <Package className="text-secondary-foreground" size={20} />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-1">
                            <h3 className="text-lg font-semibold" data-testid={`text-equipment-${rental.id}`}>
                              {rental.product?.name || "Unknown Equipment"}
                            </h3>
                            <Badge {...statusBadge}>{statusBadge.text}</Badge>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-3 text-sm text-muted-foreground">
                            <div>
                              <p className="font-medium text-foreground">Fornecedor</p>
                              <p data-testid={`text-supplier-${rental.id}`}>
                                {rental.supplier?.name || "Desconhecido"}
                              </p>
                            </div>
                            <div>
                              <p className="font-medium text-foreground">Período</p>
                              <p data-testid={`text-duration-${rental.id}`}>
                                {format(new Date(rental.startDate), "dd/MM")} - {format(new Date(rental.endDate), "dd/MM")}
                              </p>
                            </div>
                            <div>
                              <p className="font-medium text-foreground">Valor Diário</p>
                              <p data-testid={`text-rate-${rental.id}`}>R$ {rental.dailyRate}/dia</p>
                            </div>
                            <div>
                              <p className="font-medium text-foreground">Custo Total</p>
                              <p className="font-semibold text-foreground" data-testid={`text-total-${rental.id}`}>
                                R$ {totalCost}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      {rental.status === "active" && (
                        <div className="flex space-x-2 ml-4">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              returnRentalMutation.mutate(rental.id);
                            }}
                            disabled={returnRentalMutation.isPending}
                            data-testid={`button-return-${rental.id}`}
                          >
                            {returnRentalMutation.isPending ? "Devolvendo..." : "Devolver"}
                          </Button>
                        </div>
                      )}
                    </div>
                    
                    {selectedRental === rental.id && (
                      <div className="mt-4 pt-4 border-t border-border">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="font-medium mb-1">Detalhes do Equipamento</p>
                            <p>Modelo: {rental.product?.model || "N/A"}</p>
                            <p>Série: {rental.product?.serialNumber || "N/A"}</p>
                            <p>Quantidade: {rental.quantity}</p>
                          </div>
                          <div>
                            <p className="font-medium mb-1">Contato do Fornecedor</p>
                            <p>{rental.supplier?.email || "Sem email"}</p>
                            <p>{rental.supplier?.phone || "Sem telefone"}</p>
                            <p>{rental.supplier?.address || "Sem endereço"}</p>
                          </div>
                        </div>
                        {rental.notes && (
                          <div className="mt-3">
                            <p className="font-medium mb-1">Observações</p>
                            <p className="text-muted-foreground">{rental.notes}</p>
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>
      </div>
    </MainLayout>
  );
}

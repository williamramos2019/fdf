import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Search, Tags, Package } from "lucide-react";
import { api } from "@/lib/api";
import { Category } from "@/types";

export default function Categories() {
  const [searchTerm, setSearchTerm] = useState("");

  const { data: categories, isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
    queryFn: api.getCategories,
  });

  const { data: products } = useQuery({
    queryKey: ["/api/products"],
    queryFn: api.getProducts,
  });

  const filteredCategories = categories?.filter(category =>
    category.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    category.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getCategoryProductCount = (categoryId: string) => {
    return products?.filter((p: any) => p.categoryId === categoryId).length || 0;
  };

  if (isLoading) {
    return (
      <MainLayout 
        title="Categorias" 
        subtitle="Organize seus equipamentos e inventário por categorias"
      >
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-10 w-32" />
          </div>
          <Card>
            <CardContent className="p-4">
              <Skeleton className="h-16 w-full" />
            </CardContent>
          </Card>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-20 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout 
      title="Categorias" 
      subtitle="Organize seus equipamentos e inventário por categorias"
    >
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold" data-testid="text-categories-title">Categories</h1>
            <p className="text-muted-foreground" data-testid="text-categories-subtitle">
              Organize your equipment and inventory by categories
            </p>
          </div>
          <Button data-testid="button-add-category">
            <Plus className="mr-2 h-4 w-4" />
            Add Category
          </Button>
        </div>

        {/* Category Stats */}
        <Card data-testid="card-category-stats">
          <CardContent className="p-6">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Tags className="text-blue-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Categories</p>
                  <p className="text-xl font-bold">{categories?.length || 0}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                  <Package className="text-green-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Products</p>
                  <p className="text-xl font-bold">{products?.length || 0}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Search */}
        <div className="relative max-w-md">
          <Input
            type="search"
            placeholder="Search categories..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pr-10"
            data-testid="input-search-categories"
          />
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCategories?.length === 0 && searchTerm ? (
            <div className="col-span-full">
              <Card data-testid="no-search-results">
                <CardContent className="p-8 text-center">
                  <Search className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
                  <h3 className="text-sm font-medium">No categories found</h3>
                  <p className="text-xs text-muted-foreground">
                    Try adjusting your search terms
                  </p>
                </CardContent>
              </Card>
            </div>
          ) : categories?.length === 0 ? (
            <div className="col-span-full">
              <Card data-testid="empty-categories">
                <CardContent className="p-12 text-center">
                  <Tags className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No categories created</h3>
                  <p className="text-muted-foreground mb-4">
                    Categories help organize your equipment and inventory
                  </p>
                  <Button data-testid="button-first-category">
                    <Plus className="mr-2 h-4 w-4" />
                    Create First Category
                  </Button>
                </CardContent>
              </Card>
            </div>
          ) : (
            filteredCategories?.map((category) => {
              const productCount = getCategoryProductCount(category.id);
              
              return (
                <Card 
                  key={category.id} 
                  className="hover:shadow-md transition-shadow cursor-pointer"
                  data-testid={`card-category-${category.id}`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div 
                          className="w-10 h-10 rounded-lg flex items-center justify-center"
                          style={{ backgroundColor: category.color + "20" }}
                        >
                          <Tags 
                            size={20} 
                            style={{ color: category.color }}
                          />
                        </div>
                        <div>
                          <h3 className="font-semibold" data-testid={`text-category-name-${category.id}`}>
                            {category.name}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            {productCount} item{productCount !== 1 ? 's' : ''}
                          </p>
                        </div>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        data-testid={`button-edit-category-${category.id}`}
                      >
                        Edit
                      </Button>
                    </div>
                    
                    {category.description && (
                      <p className="text-sm text-muted-foreground" data-testid={`text-description-${category.id}`}>
                        {category.description}
                      </p>
                    )}
                    
                    <div className="mt-4 pt-4 border-t border-border">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Created</span>
                        <span data-testid={`text-created-${category.id}`}>
                          {new Date(category.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>

        {/* Add default categories suggestion */}
        {categories?.length === 0 && (
          <Card className="border-dashed border-2 border-muted-foreground/25" data-testid="card-suggestions">
            <CardContent className="p-6">
              <h3 className="font-semibold mb-3">Suggested Categories</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {[
                  { name: "Power Tools", color: "#3b82f6" },
                  { name: "Electronics", color: "#8b5cf6" },
                  { name: "Construction", color: "#f97316" },
                  { name: "Office Equipment", color: "#10b981" },
                  { name: "Audio/Visual", color: "#ef4444" },
                  { name: "Vehicles", color: "#f59e0b" },
                  { name: "Furniture", color: "#84cc16" },
                  { name: "Safety Equipment", color: "#06b6d4" },
                ].map((suggestion) => (
                  <Button
                    key={suggestion.name}
                    variant="outline"
                    size="sm"
                    className="justify-start text-xs h-8"
                    data-testid={`button-suggestion-${suggestion.name.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <div 
                      className="w-2 h-2 rounded-full mr-2"
                      style={{ backgroundColor: suggestion.color }}
                    />
                    {suggestion.name}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </MainLayout>
  );
}

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { FileUpload } from "@/components/ui/file-upload";
import { DocumentViewer } from "@/components/ui/document-viewer";
import { RefreshCw, Package, Plus, ArrowLeftRight, FileText, AlertTriangle, Camera, Wrench } from "lucide-react";
import { api } from "@/lib/api";
import { RentalWithDetails } from "@/types";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

interface FileWithPreview extends File {
  preview?: string;
  id: string;
}

export default function Substitution() {
  const [selectedRental, setSelectedRental] = useState<string | null>(null);
  const [problemPhotos, setProblemPhotos] = useState<FileWithPreview[]>([]);
  const [technicalReports, setTechnicalReports] = useState<FileWithPreview[]>([]);
  const [additionalDocs, setAdditionalDocs] = useState<FileWithPreview[]>([]);
  const [viewerFile, setViewerFile] = useState<{ name: string; type: string; url: string; } | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: rentals, isLoading } = useQuery<RentalWithDetails[]>({
    queryKey: ["/api/rentals"],
    queryFn: api.getRentals,
  });

  if (isLoading) {
    return (
      <MainLayout 
        title="Substituição de Equipamentos" 
        subtitle="Gerencie substituições de equipamentos alugados"
      >
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-10 w-32" />
          </div>
          <div className="grid gap-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-4">
                      <Skeleton className="w-12 h-12 rounded" />
                      <div>
                        <Skeleton className="h-5 w-32 mb-2" />
                        <Skeleton className="h-4 w-24" />
                      </div>
                    </div>
                    <Skeleton className="h-6 w-16 rounded-full" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </MainLayout>
    );
  }

  const activeRentals = rentals?.filter(r => r.status === "active") || [];

  return (
    <MainLayout 
      title="Substituição de Equipamentos" 
      subtitle="Gerencie substituições de equipamentos alugados"
    >
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Substituição de Equipamentos</h1>
            <p className="text-muted-foreground">
              Gerencie e processe substituições de equipamentos alugados
            </p>
          </div>
          <Button 
            onClick={() => {
              toast({
                title: "Nova Substituição",
                description: "Funcionalidade será implementada em breve. Por enquanto, use 'Solicitar Substituição' nos equipamentos individuais abaixo.",
              });
            }}
          >
            <Plus className="mr-2 h-4 w-4" />
            Nova Substituição
          </Button>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Package className="text-blue-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Equipamentos Ativos</p>
                  <p className="text-xl font-bold">{activeRentals.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                  <RefreshCw className="text-green-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Substituições Pendentes</p>
                  <p className="text-xl font-bold">0</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                  <ArrowLeftRight className="text-purple-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Substituições Concluídas</p>
                  <p className="text-xl font-bold">0</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Equipment Available for Substitution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <RefreshCw className="h-5 w-5" />
              <span>Equipamentos Disponíveis para Substituição</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {activeRentals.length === 0 ? (
              <div className="text-center py-12">
                <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhum equipamento ativo</h3>
                <p className="text-muted-foreground mb-4">
                  Você precisa ter equipamentos alugados ativos para realizar substituições
                </p>
                <Button variant="outline">
                  <Package className="mr-2 h-4 w-4" />
                  Ver Locações
                </Button>
              </div>
            ) : (
              <div className="grid gap-4">
                {activeRentals.map((rental) => (
                  <Card 
                    key={rental.id} 
                    className="hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => setSelectedRental(selectedRental === rental.id ? null : rental.id)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center">
                            <Package className="text-secondary-foreground" size={18} />
                          </div>
                          <div>
                            <h3 className="font-semibold">
                              {rental.product?.name || "Equipamento Desconhecido"}
                            </h3>
                            <p className="text-sm text-muted-foreground">
                              {rental.supplier?.name || "Fornecedor Desconhecido"}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Locação até: {format(new Date(rental.endDate), "dd/MM/yyyy")}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="default">Ativo</Badge>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm">
                                <RefreshCw className="mr-2 h-4 w-4" />
                                Solicitar Substituição
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                              <DialogHeader>
                                <DialogTitle className="flex items-center space-x-2">
                                  <RefreshCw className="h-5 w-5 text-blue-600" />
                                  <span>Solicitar Substituição - {rental.product?.name}</span>
                                </DialogTitle>
                              </DialogHeader>
                              
                              <div className="space-y-6 mt-6">
                                {/* Informações do Equipamento */}
                                <Card>
                                  <CardHeader>
                                    <CardTitle className="text-lg flex items-center space-x-2">
                                      <Package className="h-4 w-4" />
                                      <span>Equipamento Atual</span>
                                    </CardTitle>
                                  </CardHeader>
                                  <CardContent>
                                    <div className="grid grid-cols-2 gap-4 text-sm">
                                      <div>
                                        <p className="font-medium text-muted-foreground">Equipamento:</p>
                                        <p className="font-semibold">{rental.product?.name}</p>
                                      </div>
                                      <div>
                                        <p className="font-medium text-muted-foreground">Fornecedor:</p>
                                        <p className="font-semibold">{rental.supplier?.name}</p>
                                      </div>
                                      <div>
                                        <p className="font-medium text-muted-foreground">Modelo:</p>
                                        <p>{rental.product?.model || "N/A"}</p>
                                      </div>
                                      <div>
                                        <p className="font-medium text-muted-foreground">Série:</p>
                                        <p>{rental.product?.serialNumber || "N/A"}</p>
                                      </div>
                                    </div>
                                  </CardContent>
                                </Card>

                                {/* Documentação da Substituição */}
                                <Card className="border-orange-200">
                                  <CardHeader>
                                    <CardTitle className="flex items-center space-x-2 text-orange-700">
                                      <FileText className="h-5 w-5" />
                                      <span>Documentação da Substituição</span>
                                    </CardTitle>
                                    <p className="text-sm text-muted-foreground">
                                      Documente o problema com fotos e relatórios detalhados
                                    </p>
                                  </CardHeader>
                                  <CardContent className="space-y-6">
                                    {/* Fotos do Problema */}
                                    <div>
                                      <div className="flex items-center space-x-2 mb-3">
                                        <Camera className="h-4 w-4 text-red-600" />
                                        <span className="font-medium">Fotos do Problema</span>
                                        <Badge variant="secondary">Obrigatório</Badge>
                                      </div>
                                      <FileUpload
                                        label=""
                                        description="Fotografe o defeito, dano ou problema no equipamento para documentar a necessidade de substituição"
                                        accept="image/*"
                                        maxFiles={10}
                                        onFilesChange={setProblemPhotos}
                                        value={problemPhotos}
                                      />
                                    </div>

                                    {/* Relatórios Técnicos */}
                                    <div>
                                      <div className="flex items-center space-x-2 mb-3">
                                        <Wrench className="h-4 w-4 text-blue-600" />
                                        <span className="font-medium">Relatórios Técnicos</span>
                                      </div>
                                      <FileUpload
                                        label=""
                                        description="Laudos técnicos, relatórios de manutenção, diagnósticos de falhas"
                                        accept=".pdf,.doc,.docx"
                                        maxFiles={5}
                                        onFilesChange={setTechnicalReports}
                                        value={technicalReports}
                                      />
                                    </div>

                                    {/* Documentos Adicionais */}
                                    <div>
                                      <div className="flex items-center space-x-2 mb-3">
                                        <FileText className="h-4 w-4 text-purple-600" />
                                        <span className="font-medium">Documentos Complementares</span>
                                      </div>
                                      <FileUpload
                                        label=""
                                        description="Comunicações, orçamentos, especificações técnicas"
                                        accept=".pdf,.doc,.docx,image/*"
                                        maxFiles={8}
                                        onFilesChange={setAdditionalDocs}
                                        value={additionalDocs}
                                      />
                                    </div>

                                    {/* Resumo da Documentação */}
                                    {(problemPhotos.length > 0 || technicalReports.length > 0 || additionalDocs.length > 0) && (
                                      <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
                                        <div className="flex items-center space-x-2 mb-2">
                                          <AlertTriangle className="h-4 w-4 text-orange-600" />
                                          <h4 className="font-semibold text-orange-800">Documentação Anexada</h4>
                                        </div>
                                        <div className="grid grid-cols-3 gap-4 text-sm">
                                          <div>
                                            <p className="text-muted-foreground">Fotos do Problema:</p>
                                            <p className="font-medium">{problemPhotos.length} foto(s)</p>
                                          </div>
                                          <div>
                                            <p className="text-muted-foreground">Relatórios Técnicos:</p>
                                            <p className="font-medium">{technicalReports.length} arquivo(s)</p>
                                          </div>
                                          <div>
                                            <p className="text-muted-foreground">Docs. Complementares:</p>
                                            <p className="font-medium">{additionalDocs.length} arquivo(s)</p>
                                          </div>
                                        </div>
                                      </div>
                                    )}
                                  </CardContent>
                                </Card>

                                {/* Botões de Ação */}
                                <div className="flex justify-end space-x-4 pt-4">
                                  <Button variant="outline">
                                    Cancelar
                                  </Button>
                                  <Button 
                                    onClick={() => {
                                      if (problemPhotos.length === 0) {
                                        toast({
                                          title: "Documentação Necessária",
                                          description: "Por favor, anexe pelo menos uma foto do problema para prosseguir com a substituição.",
                                          variant: "destructive"
                                        });
                                        return;
                                      }
                                      toast({
                                        title: "Solicitação Enviada",
                                        description: "A solicitação de substituição foi enviada com toda a documentação. O fornecedor será notificado imediatamente.",
                                      });
                                      setProblemPhotos([]);
                                      setTechnicalReports([]);
                                      setAdditionalDocs([]);
                                    }}
                                  >
                                    <RefreshCw className="mr-2 h-4 w-4" />
                                    Enviar Solicitação
                                  </Button>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </div>
                      
                      {selectedRental === rental.id && (
                        <div className="mt-4 pt-4 border-t border-border">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                            <div>
                              <p className="font-medium mb-1">Detalhes do Equipamento</p>
                              <p>Modelo: {rental.product?.model || "N/A"}</p>
                              <p>Série: {rental.product?.serialNumber || "N/A"}</p>
                              <p>Quantidade: {rental.quantity}</p>
                            </div>
                            <div>
                              <p className="font-medium mb-1">Motivos Comuns para Substituição</p>
                              <div className="space-y-1">
                                <Badge variant="outline">Defeito técnico</Badge>
                                <Badge variant="outline">Manutenção preventiva</Badge>
                                <Badge variant="outline">Upgrade de modelo</Badge>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Visualizador de Documentos */}
      <DocumentViewer
        isOpen={viewerFile !== null}
        onClose={() => setViewerFile(null)}
        file={viewerFile}
      />
    </MainLayout>
  );
}
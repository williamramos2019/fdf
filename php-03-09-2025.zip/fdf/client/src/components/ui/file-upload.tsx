import React, { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Upload, File, Image, X, Eye, Download } from "lucide-react";
import { cn } from "@/lib/utils";

interface FileWithPreview extends File {
  preview?: string;
  id: string;
}

interface FileUploadProps {
  onFilesChange: (files: FileWithPreview[]) => void;
  accept?: string;
  maxFiles?: number;
  maxSize?: number; // em bytes
  className?: string;
  label?: string;
  description?: string;
  disabled?: boolean;
  value?: FileWithPreview[];
}

export function FileUpload({
  onFilesChange,
  accept = "image/*,.pdf,.doc,.docx",
  maxFiles = 10,
  maxSize = 10 * 1024 * 1024, // 10MB
  className,
  label = "Documentos",
  description = "Arraste e solte arquivos aqui ou clique para selecionar",
  disabled = false,
  value = []
}: FileUploadProps) {
  const [files, setFiles] = useState<FileWithPreview[]>(value);
  const [error, setError] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[], rejectedFiles: any[]) => {
    setError(null);

    if (rejectedFiles.length > 0) {
      const firstRejection = rejectedFiles[0];
      if (firstRejection.errors?.[0]?.code === "file-too-large") {
        setError("Arquivo muito grande. Tamanho máximo: 10MB");
      } else if (firstRejection.errors?.[0]?.code === "file-invalid-type") {
        setError("Tipo de arquivo não suportado. Use PDF, DOC, DOCX ou imagens");
      } else {
        setError("Erro ao carregar arquivo");
      }
      return;
    }

    if (files.length + acceptedFiles.length > maxFiles) {
      setError(`Máximo de ${maxFiles} arquivos permitidos`);
      return;
    }

    const newFiles: FileWithPreview[] = acceptedFiles.map(file => {
      const fileWithId = Object.assign(file, {
        id: Math.random().toString(36).substr(2, 9),
        preview: file.type.startsWith('image/') ? URL.createObjectURL(file) : undefined
      });
      return fileWithId;
    });

    const updatedFiles = [...files, ...newFiles];
    setFiles(updatedFiles);
    onFilesChange(updatedFiles);
  }, [files, maxFiles, onFilesChange]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.gif'],
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx']
    },
    maxFiles,
    maxSize,
    disabled
  });

  const removeFile = (fileId: string) => {
    const updatedFiles = files.filter(f => f.id !== fileId);
    setFiles(updatedFiles);
    onFilesChange(updatedFiles);
  };

  const getFileIcon = (file: FileWithPreview) => {
    if (file.type.startsWith('image/')) return <Image className="w-4 h-4" />;
    return <File className="w-4 h-4" />;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className={cn("space-y-4", className)}>
      <div className="space-y-2">
        <label className="text-sm font-medium">{label}</label>
        
        {/* Área de Upload */}
        <Card>
          <CardContent 
            {...getRootProps()} 
            className={cn(
              "p-6 text-center cursor-pointer transition-colors border-2 border-dashed",
              isDragActive ? "border-primary bg-primary/10" : "border-muted-foreground/25",
              disabled && "opacity-50 cursor-not-allowed"
            )}
          >
            <input {...getInputProps()} />
            <div className="space-y-2">
              <Upload className="w-8 h-8 mx-auto text-muted-foreground" />
              <p className="text-sm text-muted-foreground">{description}</p>
              <p className="text-xs text-muted-foreground">
                PDF, DOC, DOCX, Imagens • Máx {formatFileSize(maxSize)}
              </p>
            </div>
          </CardContent>
        </Card>

        {error && (
          <div className="text-sm text-destructive bg-destructive/10 p-3 rounded-md">
            {error}
          </div>
        )}
      </div>

      {/* Lista de Arquivos */}
      {files.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-sm font-medium">Arquivos Anexados ({files.length})</h4>
          <div className="space-y-2">
            {files.map((file) => (
              <Card key={file.id}>
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3 flex-1 min-w-0">
                      {getFileIcon(file)}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{file.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {formatFileSize(file.size)}
                        </p>
                      </div>
                      <Badge variant={file.type.startsWith('image/') ? 'default' : 'secondary'}>
                        {file.type.startsWith('image/') ? 'Imagem' : 'Documento'}
                      </Badge>
                    </div>
                    <div className="flex items-center space-x-2 ml-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          // Aqui será implementada a visualização
                          console.log('Visualizar:', file.name);
                        }}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => removeFile(file.id)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
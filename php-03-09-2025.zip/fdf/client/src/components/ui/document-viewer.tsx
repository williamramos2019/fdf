import React from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, X, ZoomIn, ZoomOut } from "lucide-react";
import { useState } from "react";

interface DocumentViewerProps {
  isOpen: boolean;
  onClose: () => void;
  file: {
    name: string;
    type: string;
    url: string;
    size?: number;
  } | null;
}

export function DocumentViewer({ isOpen, onClose, file }: DocumentViewerProps) {
  const [zoom, setZoom] = useState(1);

  if (!file) return null;

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = file.url;
    link.download = file.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 0.25, 3));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 0.25, 0.5));
  };

  const isImage = file.type.startsWith('image/');
  const isPdf = file.type === 'application/pdf';

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh] p-0 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b bg-background">
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold truncate">{file.name}</h3>
            <p className="text-sm text-muted-foreground">
              {file.type} • {file.size && `${(file.size / 1024 / 1024).toFixed(2)} MB`}
            </p>
          </div>
          
          <div className="flex items-center space-x-2 ml-4">
            {isImage && (
              <>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleZoomOut}
                  disabled={zoom <= 0.5}
                >
                  <ZoomOut className="w-4 h-4" />
                </Button>
                <span className="text-sm px-2">{Math.round(zoom * 100)}%</span>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleZoomIn}
                  disabled={zoom >= 3}
                >
                  <ZoomIn className="w-4 h-4" />
                </Button>
              </>
            )}
            
            <Button
              size="sm"
              variant="outline"
              onClick={handleDownload}
            >
              <Download className="w-4 h-4 mr-2" />
              Download
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              onClick={onClose}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto bg-muted/30 p-4">
          <div className="flex justify-center">
            {isImage && (
              <img
                src={file.url}
                alt={file.name}
                className="max-w-full h-auto"
                style={{ 
                  transform: `scale(${zoom})`,
                  transformOrigin: 'center top'
                }}
              />
            )}
            
            {isPdf && (
              <iframe
                src={file.url}
                className="w-full h-full min-h-[600px] border-0"
                title={file.name}
              />
            )}
            
            {!isImage && !isPdf && (
              <div className="text-center py-20">
                <div className="space-y-4">
                  <div className="w-16 h-16 mx-auto bg-muted rounded-lg flex items-center justify-center">
                    <Download className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Preview não disponível</h4>
                    <p className="text-sm text-muted-foreground">
                      Este tipo de arquivo não pode ser visualizado no navegador.
                    </p>
                  </div>
                  <Button onClick={handleDownload}>
                    <Download className="w-4 h-4 mr-2" />
                    Fazer Download para Visualizar
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
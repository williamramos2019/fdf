import { apiRequest } from "./queryClient";

// API helper functions
export const api = {
  // Dashboard
  getDashboardStats: () => fetch("/api/dashboard/stats").then(res => res.json()),
  getRecentRentals: () => fetch("/api/dashboard/recent-rentals").then(res => res.json()),
  
  // Rentals
  getRentals: () => fetch("/api/rentals").then(res => res.json()),
  getRental: (id: string) => fetch(`/api/rentals/${id}`).then(res => res.json()),
  createRental: (data: any) => apiRequest("POST", "/api/rentals", data),
  updateRental: (id: string, data: any) => apiRequest("PUT", `/api/rentals/${id}`, data),
  deleteRental: (id: string) => apiRequest("DELETE", `/api/rentals/${id}`),
  returnRental: (id: string) => apiRequest("POST", `/api/rentals/${id}/return`),
  
  // Suppliers
  getSuppliers: () => fetch("/api/suppliers").then(res => res.json()),
  getSupplier: (id: string) => fetch(`/api/suppliers/${id}`).then(res => res.json()),
  createSupplier: (data: any) => apiRequest("POST", "/api/suppliers", data),
  updateSupplier: (id: string, data: any) => apiRequest("PUT", `/api/suppliers/${id}`, data),
  deleteSupplier: (id: string) => apiRequest("DELETE", `/api/suppliers/${id}`),
  
  // Products/Inventory
  getProducts: () => fetch("/api/products").then(res => res.json()),
  getProduct: (id: string) => fetch(`/api/products/${id}`).then(res => res.json()),
  createProduct: (data: any) => apiRequest("POST", "/api/products", data),
  updateProduct: (id: string, data: any) => apiRequest("PUT", `/api/products/${id}`, data),
  deleteProduct: (id: string) => apiRequest("DELETE", `/api/products/${id}`),
  
  // Categories
  getCategories: () => fetch("/api/categories").then(res => res.json()),
  getCategory: (id: string) => fetch(`/api/categories/${id}`).then(res => res.json()),
  createCategory: (data: any) => apiRequest("POST", "/api/categories", data),
  updateCategory: (id: string, data: any) => apiRequest("PUT", `/api/categories/${id}`, data),
  deleteCategory: (id: string) => apiRequest("DELETE", `/api/categories/${id}`),
  
  // Inventory Movements
  getInventoryMovements: () => fetch("/api/inventory/movements").then(res => res.json()),
  createInventoryMovement: (data: any) => apiRequest("POST", "/api/inventory/movements", data),
  
  // Reports
  getExpenseReport: (period: string) => fetch(`/api/reports/expenses?period=${period}`).then(res => res.json()),
  getInventoryReport: () => fetch("/api/reports/inventory").then(res => res.json()),
};

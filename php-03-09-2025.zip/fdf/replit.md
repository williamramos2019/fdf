# Overview

This is a full-stack personal rental and inventory management system (Sistema de Gerenciamento de Aluguel e Inventário Pessoal) built with React, TypeScript, and Express.js. The application helps individuals or small businesses track equipment they rent from suppliers, manage their inventory, and monitor rental expenses. The system is designed from a consumer perspective rather than a rental provider, focusing on tracking equipment rented FROM suppliers.

**IMPORTANT: This system follows the exact layout and functionalities from the original GitHub repository (https://github.com/williamramos2019/sada.git). The interface is completely in Portuguese and maintains the original design specifications.**

# User Preferences

- Preferred communication style: Simple, everyday language
- Interface language: Portuguese (all labels, navigation, and content)
- Design requirement: Must follow the original GitHub repository layout exactly
- Layout memory: Always remember this specific layout and functionalities for future uploads

# System Architecture

## Frontend Architecture
The client uses React 18 with TypeScript and Vite as the build tool, following a component-based architecture:

- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management with infinite stale time and no automatic refetching
- **UI Components**: shadcn/ui component library built on Radix UI primitives with comprehensive component coverage
- **Styling**: Tailwind CSS with CSS custom properties for theming support, including dark mode capability
- **Forms**: React Hook Form with Zod validation for type-safe form handling
- **Layout**: Responsive layout with collapsible sidebar navigation and mobile-friendly header
- **Types**: Local TypeScript definitions replacing shared schema imports for better frontend isolation

The application follows a page-based structure with dedicated routes for:
- **Dashboard** (Painel de Controle): Main overview with rental statistics and recent activity
- **Rentals** (Locações): Equipment rental management with hierarchical navigation:
  - Equipamentos Alugados (Active rentals)
  - Novo Aluguel (New rental)
  - Relatórios (Reports)
- **Inventory** (Almoxarifado): Stock and equipment management:
  - Estoque (Stock)
  - Movimentações (Movements)
  - Cadastrar Produto (Add product)
  - Substituição (Substitution) - Important module that manages equipment substitutions
- **Suppliers** (Fornecedores): Supplier management
- **Categories** (Categorias): Equipment and inventory categorization
- **Reports** (Relatórios): Expense tracking and inventory insights

The UI is fully responsive with mobile-first design considerations and uses a hierarchical sidebar navigation organized by sections.

## Backend Architecture
The server is built with Express.js and Node.js using TypeScript:

- **Framework**: Express.js with TypeScript for type safety
- **API Design**: RESTful endpoints organized by resource (suppliers, products, rentals, categories)
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema**: Shared schema definitions using Drizzle with Zod validation
- **Session Management**: Connect-pg-simple for PostgreSQL-based session storage
- **Development**: Hot module replacement with Vite integration for seamless development experience

The backend follows a layered architecture with storage abstraction, route handlers, and comprehensive error handling middleware.

## Data Storage
PostgreSQL database with Drizzle ORM providing:

- **Schema Management**: Type-safe schema definitions with automatic migrations
- **Relationships**: Proper foreign key relationships between entities (products→categories, rentals→products/suppliers)
- **Validation**: Zod schemas for runtime validation and type inference
- **Migrations**: Automated database migrations with drizzle-kit

Key entities include users, categories, suppliers, products, rentals, and inventory movements with proper indexing and constraints.

## Authentication and State Management
- **Session-based Authentication**: Server-side sessions with PostgreSQL storage
- **Client State**: TanStack Query for server state with optimistic updates
- **Form State**: React Hook Form with real-time validation
- **UI State**: React hooks for component-level state management

The system uses HTTP-only cookies for secure session management and implements proper CSRF protection.

# External Dependencies

## Database Services
- **Neon Database**: PostgreSQL hosting service configured through DATABASE_URL environment variable
- **Drizzle ORM**: Type-safe database operations with PostgreSQL dialect

## UI and Styling
- **Radix UI**: Comprehensive primitive components for accessibility and behavior
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **Lucide React**: Icon library for consistent iconography
- **shadcn/ui**: Pre-built component library with customizable design tokens

## Development Tools
- **Vite**: Fast build tool with HMR and development server
- **TypeScript**: Type safety across frontend and backend
- **Replit Integration**: Development environment with cartographer plugin and runtime error overlay

## Form and Validation
- **React Hook Form**: Performant form handling with minimal re-renders
- **Zod**: Schema validation for both frontend forms and backend API
- **@hookform/resolvers**: Zod integration for React Hook Form

## Date and Utility Libraries
- **date-fns**: Date manipulation and formatting
- **clsx**: Conditional className utility
- **class-variance-authority**: Component variant management for consistent styling

# Original Layout Specifications

## Design System
- **Primary Colors**: Blue-based color scheme with purple accents
- **Layout Structure**: MainLayout with collapsible Sidebar and Header components
- **Navigation**: Hierarchical sidebar with sections for "Locações" and "Almoxarifado"
- **Components**: StatsCard for dashboard metrics, StatusBadge for status indicators
- **Typography**: Portuguese labels throughout the interface
- **User Profile**: William Ramos as administrator with settings access

## Key Interface Elements
- **Header**: Shows current date and notification system
- **Sidebar**: Organized by functional sections with expandable navigation
- **Dashboard**: Statistics cards showing active rentals, monthly expenses, stock items, and low stock alerts
- **Color Scheme**: Uses CSS custom properties with proper HSL format for theming
- **Icons**: Lucide React icons for consistent visual language

## Critical Features
- **Substituição Module**: Essential equipment substitution management feature
- **Portuguese Interface**: All text, navigation, and labels in Portuguese
- **Original Design Compliance**: Must maintain exact layout from reference repository
- **Responsive Design**: Mobile-first approach with collapsible navigation

This layout and functionality specification should be preserved and referenced for any future development or uploads.
import { 
  type User, 
  type InsertUser,
  type Category,
  type InsertCategory,
  type Supplier,
  type InsertSupplier,
  type Product,
  type InsertProduct,
  type Rental,
  type InsertRental,
  type InventoryMovement,
  type InsertInventoryMovement
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Category operations
  getCategories(): Promise<Category[]>;
  getCategory(id: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: string, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: string): Promise<boolean>;

  // Supplier operations
  getSuppliers(): Promise<Supplier[]>;
  getSupplier(id: string): Promise<Supplier | undefined>;
  createSupplier(supplier: InsertSupplier): Promise<Supplier>;
  updateSupplier(id: string, supplier: Partial<InsertSupplier>): Promise<Supplier | undefined>;
  deleteSupplier(id: string): Promise<boolean>;

  // Product operations
  getProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;

  // Rental operations
  getRentals(): Promise<Rental[]>;
  getRental(id: string): Promise<Rental | undefined>;
  createRental(rental: InsertRental): Promise<Rental>;
  updateRental(id: string, rental: Partial<InsertRental>): Promise<Rental | undefined>;
  deleteRental(id: string): Promise<boolean>;
  returnRental(id: string): Promise<Rental | undefined>;

  // Inventory movement operations
  getInventoryMovements(): Promise<InventoryMovement[]>;
  createInventoryMovement(movement: InsertInventoryMovement): Promise<InventoryMovement>;

  // Dashboard operations
  getDashboardStats(): Promise<{
    activeRentals: number;
    monthlyExpenses: string;
    inventoryItems: number;
    suppliers: number;
    overdueRentals: number;
    lowStockItems: number;
  }>;
  getRecentRentals(): Promise<Rental[]>;
  
  // Reports
  getExpenseReport(period: string): Promise<any>;
  getInventoryReport(): Promise<any>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private categories: Map<string, Category>;
  private suppliers: Map<string, Supplier>;
  private products: Map<string, Product>;
  private rentals: Map<string, Rental>;
  private inventoryMovements: Map<string, InventoryMovement>;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.suppliers = new Map();
    this.products = new Map();
    this.rentals = new Map();
    this.inventoryMovements = new Map();
    this.initializeTestData();
  }

  private initializeTestData() {
    // Add default user
    const defaultUser: User = {
      id: randomUUID(),
      username: "manager",
      password: "password",
      name: "John Doe",
      email: "john.doe@example.com",
      role: "manager",
      createdAt: new Date(),
    };
    this.users.set(defaultUser.id, defaultUser);

    // Add sample categories
    const categories = [
      { name: "Power Tools", description: "Electric and battery-powered tools", color: "#3b82f6" },
      { name: "Electronics", description: "Computers, cameras, and electronic equipment", color: "#8b5cf6" },
      { name: "Construction", description: "Heavy construction equipment", color: "#f97316" },
    ];

    categories.forEach(cat => {
      const category: Category = {
        id: randomUUID(),
        ...cat,
        createdAt: new Date(),
      };
      this.categories.set(category.id, category);
    });

    // Add sample suppliers
    const suppliers = [
      { 
        name: "ToolCorp Inc.", 
        contactPerson: "Mike Johnson",
        email: "mike@toolcorp.com",
        phone: "(555) 123-4567",
        address: "123 Industrial Ave, City, ST 12345",
        isActive: true
      },
      { 
        name: "TechRentals LLC", 
        contactPerson: "Sarah Wilson",
        email: "sarah@techrentals.com",
        phone: "(555) 987-6543",
        address: "456 Tech Park Dr, City, ST 12345",
        isActive: true
      },
      { 
        name: "PhotoPro Rentals", 
        contactPerson: "David Chen",
        email: "david@photopro.com",
        phone: "(555) 456-7890",
        address: "789 Camera St, City, ST 12345",
        isActive: true
      },
    ];

    suppliers.forEach(sup => {
      const supplier: Supplier = {
        id: randomUUID(),
        ...sup,
        notes: undefined,
        createdAt: new Date(),
      };
      this.suppliers.set(supplier.id, supplier);
    });

    // Add sample products
    const categoryIds = Array.from(this.categories.keys());
    const products = [
      {
        name: "Power Drill Set",
        description: "Professional cordless drill with bits",
        model: "PD-2000X",
        serialNumber: "PD001234",
        categoryId: categoryIds[0],
        currentStock: 5,
        minStock: 2,
        unitCost: "150.00",
        isActive: true
      },
      {
        name: "Laptop Computer",
        description: "Business laptop for presentations",
        model: "ThinkPad X1",
        serialNumber: "LP001235",
        categoryId: categoryIds[1],
        currentStock: 3,
        minStock: 1,
        unitCost: "1200.00",
        isActive: true
      },
      {
        name: "DSLR Camera Kit",
        description: "Professional camera with lenses",
        model: "Canon EOS R5",
        serialNumber: "CAM001236",
        categoryId: categoryIds[1],
        currentStock: 2,
        minStock: 1,
        unitCost: "3500.00",
        isActive: true
      },
    ];

    products.forEach(prod => {
      const product: Product = {
        id: randomUUID(),
        ...prod,
        createdAt: new Date(),
      };
      this.products.set(product.id, product);
    });

    // Add sample rentals
    const supplierIds = Array.from(this.suppliers.keys());
    const productIds = Array.from(this.products.keys());
    const rentals = [
      {
        productId: productIds[0],
        supplierId: supplierIds[0],
        quantity: 1,
        dailyRate: "45.00",
        startDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
        endDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000), // 10 days from now
        status: "active",
        notes: "For construction project"
      },
      {
        productId: productIds[1],
        supplierId: supplierIds[1],
        quantity: 1,
        dailyRate: "25.00",
        startDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
        endDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000), // 1 day from now (due soon)
        status: "active",
        notes: "For business presentation"
      },
      {
        productId: productIds[2],
        supplierId: supplierIds[2],
        quantity: 1,
        dailyRate: "85.00",
        startDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000), // 15 days ago
        endDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago (overdue)
        status: "active",
        notes: "Wedding photography equipment"
      },
    ];

    rentals.forEach(rent => {
      const rental: Rental = {
        id: randomUUID(),
        ...rent,
        returnedDate: undefined,
        totalCost: undefined,
        createdAt: new Date(),
      };
      this.rentals.set(rental.id, rental);
    });
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values()).sort((a, b) => a.name.localeCompare(b.name));
  }

  async getCategory(id: string): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = randomUUID();
    const category: Category = { ...insertCategory, id, createdAt: new Date() };
    this.categories.set(id, category);
    return category;
  }

  async updateCategory(id: string, updateData: Partial<InsertCategory>): Promise<Category | undefined> {
    const existing = this.categories.get(id);
    if (!existing) return undefined;
    
    const updated: Category = { ...existing, ...updateData };
    this.categories.set(id, updated);
    return updated;
  }

  async deleteCategory(id: string): Promise<boolean> {
    return this.categories.delete(id);
  }

  // Supplier operations
  async getSuppliers(): Promise<Supplier[]> {
    return Array.from(this.suppliers.values()).sort((a, b) => a.name.localeCompare(b.name));
  }

  async getSupplier(id: string): Promise<Supplier | undefined> {
    return this.suppliers.get(id);
  }

  async createSupplier(insertSupplier: InsertSupplier): Promise<Supplier> {
    const id = randomUUID();
    const supplier: Supplier = { ...insertSupplier, id, createdAt: new Date() };
    this.suppliers.set(id, supplier);
    return supplier;
  }

  async updateSupplier(id: string, updateData: Partial<InsertSupplier>): Promise<Supplier | undefined> {
    const existing = this.suppliers.get(id);
    if (!existing) return undefined;
    
    const updated: Supplier = { ...existing, ...updateData };
    this.suppliers.set(id, updated);
    return updated;
  }

  async deleteSupplier(id: string): Promise<boolean> {
    return this.suppliers.delete(id);
  }

  // Product operations
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).sort((a, b) => a.name.localeCompare(b.name));
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = { ...insertProduct, id, createdAt: new Date() };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: string, updateData: Partial<InsertProduct>): Promise<Product | undefined> {
    const existing = this.products.get(id);
    if (!existing) return undefined;
    
    const updated: Product = { ...existing, ...updateData };
    this.products.set(id, updated);
    return updated;
  }

  async deleteProduct(id: string): Promise<boolean> {
    return this.products.delete(id);
  }

  // Rental operations
  async getRentals(): Promise<Rental[]> {
    return Array.from(this.rentals.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getRental(id: string): Promise<Rental | undefined> {
    return this.rentals.get(id);
  }

  async createRental(insertRental: InsertRental): Promise<Rental> {
    const id = randomUUID();
    const rental: Rental = { 
      ...insertRental, 
      id, 
      createdAt: new Date(),
      totalCost: undefined 
    };
    this.rentals.set(id, rental);
    return rental;
  }

  async updateRental(id: string, updateData: Partial<InsertRental>): Promise<Rental | undefined> {
    const existing = this.rentals.get(id);
    if (!existing) return undefined;
    
    const updated: Rental = { ...existing, ...updateData };
    this.rentals.set(id, updated);
    return updated;
  }

  async deleteRental(id: string): Promise<boolean> {
    return this.rentals.delete(id);
  }

  async returnRental(id: string): Promise<Rental | undefined> {
    const existing = this.rentals.get(id);
    if (!existing) return undefined;
    
    const updated: Rental = { 
      ...existing, 
      status: "returned",
      returnedDate: new Date()
    };
    this.rentals.set(id, updated);
    return updated;
  }

  // Inventory movement operations
  async getInventoryMovements(): Promise<InventoryMovement[]> {
    return Array.from(this.inventoryMovements.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async createInventoryMovement(insertMovement: InsertInventoryMovement): Promise<InventoryMovement> {
    const id = randomUUID();
    const movement: InventoryMovement = { ...insertMovement, id, createdAt: new Date() };
    this.inventoryMovements.set(id, movement);
    return movement;
  }

  // Dashboard operations
  async getDashboardStats() {
    const activeRentals = Array.from(this.rentals.values()).filter(r => r.status === "active").length;
    const overdueRentals = Array.from(this.rentals.values()).filter(r => 
      r.status === "active" && new Date() > new Date(r.endDate)
    ).length;
    const inventoryItems = Array.from(this.products.values()).length;
    const suppliers = Array.from(this.suppliers.values()).filter(s => s.isActive).length;
    const lowStockItems = Array.from(this.products.values()).filter(p => 
      p.currentStock <= p.minStock
    ).length;

    // Calculate monthly expenses from active rentals
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    
    const monthlyExpenses = Array.from(this.rentals.values())
      .filter(r => {
        const startDate = new Date(r.startDate);
        return startDate.getMonth() === currentMonth && startDate.getFullYear() === currentYear;
      })
      .reduce((total, rental) => {
        const days = Math.ceil((new Date(rental.endDate).getTime() - new Date(rental.startDate).getTime()) / (1000 * 60 * 60 * 24));
        return total + (parseFloat(rental.dailyRate) * days * rental.quantity);
      }, 0);

    return {
      activeRentals,
      monthlyExpenses: monthlyExpenses.toFixed(0),
      inventoryItems,
      suppliers,
      overdueRentals,
      lowStockItems,
    };
  }

  async getRecentRentals(): Promise<Rental[]> {
    return Array.from(this.rentals.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5);
  }

  async getExpenseReport(period: string) {
    const rentals = Array.from(this.rentals.values());
    const now = new Date();
    let startDate: Date;

    switch (period) {
      case "3months":
        startDate = new Date(now.getFullYear(), now.getMonth() - 3, 1);
        break;
      case "6months":
        startDate = new Date(now.getFullYear(), now.getMonth() - 6, 1);
        break;
      case "12months":
        startDate = new Date(now.getFullYear(), now.getMonth() - 12, 1);
        break;
      case "year":
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
      default:
        startDate = new Date(now.getFullYear(), now.getMonth() - 6, 1);
    }

    const filteredRentals = rentals.filter(r => new Date(r.startDate) >= startDate);
    
    const totalExpenses = filteredRentals.reduce((total, rental) => {
      const days = Math.ceil((new Date(rental.endDate).getTime() - new Date(rental.startDate).getTime()) / (1000 * 60 * 60 * 24));
      return total + (parseFloat(rental.dailyRate) * days * rental.quantity);
    }, 0);

    const monthsInPeriod = Math.max(1, Math.ceil((now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24 * 30)));
    const avgMonthlyExpense = (totalExpenses / monthsInPeriod).toFixed(0);

    // Generate chart data for the last 6 months
    const chartData = [];
    for (let i = 5; i >= 0; i--) {
      const monthDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthEnd = new Date(now.getFullYear(), now.getMonth() - i + 1, 0);
      
      const monthExpenses = rentals
        .filter(r => {
          const start = new Date(r.startDate);
          return start >= monthDate && start <= monthEnd;
        })
        .reduce((total, rental) => {
          const days = Math.ceil((new Date(rental.endDate).getTime() - new Date(rental.startDate).getTime()) / (1000 * 60 * 60 * 24));
          return total + (parseFloat(rental.dailyRate) * days * rental.quantity);
        }, 0);

      chartData.push({
        month: monthDate.toLocaleDateString('en-US', { month: 'short' }),
        amount: monthExpenses
      });
    }

    return {
      totalExpenses: totalExpenses.toFixed(0),
      avgMonthlyExpense,
      avgDailyCost: (totalExpenses / Math.max(1, (now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))).toFixed(0),
      trend: "+5%", // Mock trend
      chartData
    };
  }

  async getInventoryReport() {
    const products = Array.from(this.products.values());
    const categories = Array.from(this.categories.values());
    
    const totalItems = products.length;
    const totalValue = products.reduce((total, product) => {
      const cost = parseFloat(product.unitCost || "0");
      return total + (cost * product.currentStock);
    }, 0);
    
    const lowStockItems = products.filter(p => p.currentStock <= p.minStock).length;
    const lowStockList = products.filter(p => p.currentStock <= p.minStock);
    
    const categoryBreakdown = categories.map(category => {
      const categoryProducts = products.filter(p => p.categoryId === category.id);
      const categoryValue = categoryProducts.reduce((total, product) => {
        const cost = parseFloat(product.unitCost || "0");
        return total + (cost * product.currentStock);
      }, 0);
      
      return {
        id: category.id,
        name: category.name,
        itemCount: categoryProducts.length,
        totalValue: categoryValue.toFixed(0)
      };
    });

    return {
      totalItems,
      totalValue: totalValue.toFixed(0),
      lowStockItems,
      totalCategories: categories.length,
      lowStockList,
      categoryBreakdown
    };
  }
}

export const storage = new MemStorage();

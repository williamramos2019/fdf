import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertCategorySchema,
  insertSupplierSchema,
  insertProductSchema,
  insertRentalSchema,
  insertInventoryMovementSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Dashboard routes
  app.get("/api/dashboard/stats", async (_req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  app.get("/api/dashboard/recent-rentals", async (_req, res) => {
    try {
      const rentals = await storage.getRecentRentals();
      
      // Enhance rentals with product and supplier data
      const enhancedRentals = await Promise.all(
        rentals.map(async (rental) => {
          const product = rental.productId ? await storage.getProduct(rental.productId) : undefined;
          const supplier = rental.supplierId ? await storage.getSupplier(rental.supplierId) : undefined;
          
          // Determine status based on dates
          let status = rental.status;
          if (status === "active") {
            const now = new Date();
            const endDate = new Date(rental.endDate);
            const timeDiff = endDate.getTime() - now.getTime();
            const daysDiff = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
            
            if (now > endDate) {
              status = "overdue";
            } else if (daysDiff <= 1) {
              status = "due_soon";
            }
          }
          
          return {
            ...rental,
            status,
            product,
            supplier
          };
        })
      );
      
      res.json(enhancedRentals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recent rentals" });
    }
  });

  // Category routes
  app.get("/api/categories", async (_req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get("/api/categories/:id", async (req, res) => {
    try {
      const category = await storage.getCategory(req.params.id);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch category" });
    }
  });

  app.post("/api/categories", async (req, res) => {
    try {
      const validatedData = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(validatedData);
      res.status(201).json(category);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Invalid category data" });
    }
  });

  app.put("/api/categories/:id", async (req, res) => {
    try {
      const validatedData = insertCategorySchema.partial().parse(req.body);
      const category = await storage.updateCategory(req.params.id, validatedData);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      res.json(category);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Invalid category data" });
    }
  });

  app.delete("/api/categories/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteCategory(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Category not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete category" });
    }
  });

  // Supplier routes
  app.get("/api/suppliers", async (_req, res) => {
    try {
      const suppliers = await storage.getSuppliers();
      res.json(suppliers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch suppliers" });
    }
  });

  app.get("/api/suppliers/:id", async (req, res) => {
    try {
      const supplier = await storage.getSupplier(req.params.id);
      if (!supplier) {
        return res.status(404).json({ message: "Supplier not found" });
      }
      res.json(supplier);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch supplier" });
    }
  });

  app.post("/api/suppliers", async (req, res) => {
    try {
      const validatedData = insertSupplierSchema.parse(req.body);
      const supplier = await storage.createSupplier(validatedData);
      res.status(201).json(supplier);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Invalid supplier data" });
    }
  });

  app.put("/api/suppliers/:id", async (req, res) => {
    try {
      const validatedData = insertSupplierSchema.partial().parse(req.body);
      const supplier = await storage.updateSupplier(req.params.id, validatedData);
      if (!supplier) {
        return res.status(404).json({ message: "Supplier not found" });
      }
      res.json(supplier);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Invalid supplier data" });
    }
  });

  app.delete("/api/suppliers/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteSupplier(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Supplier not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete supplier" });
    }
  });

  // Product routes
  app.get("/api/products", async (_req, res) => {
    try {
      const products = await storage.getProducts();
      
      // Enhance products with category data
      const enhancedProducts = await Promise.all(
        products.map(async (product) => {
          const category = product.categoryId ? await storage.getCategory(product.categoryId) : undefined;
          return {
            ...product,
            category
          };
        })
      );
      
      res.json(enhancedProducts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      const category = product.categoryId ? await storage.getCategory(product.categoryId) : undefined;
      res.json({ ...product, category });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  app.post("/api/products", async (req, res) => {
    try {
      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(validatedData);
      res.status(201).json(product);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Invalid product data" });
    }
  });

  app.put("/api/products/:id", async (req, res) => {
    try {
      const validatedData = insertProductSchema.partial().parse(req.body);
      const product = await storage.updateProduct(req.params.id, validatedData);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Invalid product data" });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteProduct(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // Rental routes
  app.get("/api/rentals", async (_req, res) => {
    try {
      const rentals = await storage.getRentals();
      
      // Enhance rentals with product and supplier data
      const enhancedRentals = await Promise.all(
        rentals.map(async (rental) => {
          const product = rental.productId ? await storage.getProduct(rental.productId) : undefined;
          const supplier = rental.supplierId ? await storage.getSupplier(rental.supplierId) : undefined;
          
          // Determine status based on dates
          let status = rental.status;
          if (status === "active") {
            const now = new Date();
            const endDate = new Date(rental.endDate);
            const timeDiff = endDate.getTime() - now.getTime();
            const daysDiff = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
            
            if (now > endDate) {
              status = "overdue";
            } else if (daysDiff <= 1) {
              status = "due_soon";
            }
          }
          
          return {
            ...rental,
            status,
            product,
            supplier
          };
        })
      );
      
      res.json(enhancedRentals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch rentals" });
    }
  });

  app.get("/api/rentals/:id", async (req, res) => {
    try {
      const rental = await storage.getRental(req.params.id);
      if (!rental) {
        return res.status(404).json({ message: "Rental not found" });
      }
      
      const product = rental.productId ? await storage.getProduct(rental.productId) : undefined;
      const supplier = rental.supplierId ? await storage.getSupplier(rental.supplierId) : undefined;
      
      res.json({ ...rental, product, supplier });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch rental" });
    }
  });

  app.post("/api/rentals", async (req, res) => {
    try {
      const validatedData = insertRentalSchema.parse(req.body);
      const rental = await storage.createRental(validatedData);
      res.status(201).json(rental);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Invalid rental data" });
    }
  });

  app.put("/api/rentals/:id", async (req, res) => {
    try {
      const validatedData = insertRentalSchema.partial().parse(req.body);
      const rental = await storage.updateRental(req.params.id, validatedData);
      if (!rental) {
        return res.status(404).json({ message: "Rental not found" });
      }
      res.json(rental);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Invalid rental data" });
    }
  });

  app.post("/api/rentals/:id/return", async (req, res) => {
    try {
      const rental = await storage.returnRental(req.params.id);
      if (!rental) {
        return res.status(404).json({ message: "Rental not found" });
      }
      res.json(rental);
    } catch (error) {
      res.status(500).json({ message: "Failed to return rental" });
    }
  });

  app.delete("/api/rentals/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteRental(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Rental not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete rental" });
    }
  });

  // Inventory movement routes
  app.get("/api/inventory/movements", async (_req, res) => {
    try {
      const movements = await storage.getInventoryMovements();
      res.json(movements);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch inventory movements" });
    }
  });

  app.post("/api/inventory/movements", async (req, res) => {
    try {
      const validatedData = insertInventoryMovementSchema.parse(req.body);
      const movement = await storage.createInventoryMovement(validatedData);
      res.status(201).json(movement);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Invalid movement data" });
    }
  });

  // Report routes
  app.get("/api/reports/expenses", async (req, res) => {
    try {
      const period = req.query.period as string || "6months";
      const report = await storage.getExpenseReport(period);
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate expense report" });
    }
  });

  app.get("/api/reports/inventory", async (_req, res) => {
    try {
      const report = await storage.getInventoryReport();
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate inventory report" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}

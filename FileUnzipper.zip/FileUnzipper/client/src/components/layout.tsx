import { useState, useEffect } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { AppSidebar } from "./app-sidebar";
import { Header } from "./header";

interface LayoutProps {
  children: React.ReactNode;
  title: string;
}

export function Layout({ children, title }: LayoutProps) {
  const isMobile = useIsMobile();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const handleSidebarToggle = () => {
    if (isMobile) {
      setIsSidebarOpen(!isSidebarOpen);
    } else {
      setIsCollapsed(!isCollapsed);
    }
  };

  const handleSidebarCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
  };

  // Close mobile sidebar on route change
  useEffect(() => {
    if (isMobile) {
      setIsSidebarOpen(false);
    }
  }, [title, isMobile]);

  return (
    <div className="flex h-screen bg-background" data-testid="layout">
      <AppSidebar
        isCollapsed={isCollapsed}
        onToggle={handleSidebarToggle}
        isMobile={isMobile}
        isOpen={isSidebarOpen}
        onClose={closeSidebar}
      />
      
      {/* Mobile Overlay */}
      {isMobile && isSidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={closeSidebar}
          data-testid="sidebar-overlay"
        />
      )}
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header
          title={title}
          onSidebarToggle={handleSidebarToggle}
          onSidebarCollapse={handleSidebarCollapse}
          isMobile={isMobile}
        />
        
        <main className="flex-1 overflow-auto p-6 bg-background" data-testid="main-content">
          {children}
        </main>
      </div>
    </div>
  );
}

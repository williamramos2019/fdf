import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { 
  BarChart3, 
  Handshake, 
  Warehouse, 
  Truck, 
  Tags, 
  ChartBar, 
  Package2,
  User,
  Menu
} from "lucide-react";
import { cn } from "@/lib/utils";

interface AppSidebarProps {
  isCollapsed: boolean;
  onToggle: () => void;
  isMobile: boolean;
  isOpen: boolean;
  onClose: () => void;
}

export function AppSidebar({ isCollapsed, onToggle, isMobile, isOpen, onClose }: AppSidebarProps) {
  const [location] = useLocation();
  
  const navItems = [
    { href: "/", icon: BarChart3, label: "Dashboard" },
    { href: "/rentals", icon: Handshake, label: "Active Rentals" },
    { href: "/inventory", icon: Warehouse, label: "My Inventory" },
    { href: "/suppliers", icon: Truck, label: "Suppliers" },
    { href: "/categories", icon: Tags, label: "Categories" },
    { href: "/reports", icon: ChartBar, label: "Reports" },
  ];

  const sidebarClasses = cn(
    "bg-sidebar border-r border-sidebar-border flex flex-col transition-all duration-300 ease-in-out h-full",
    {
      "sidebar-collapsed": isCollapsed && !isMobile,
      "sidebar-expanded": !isCollapsed && !isMobile,
      "sidebar-mobile": isMobile,
      "open": isMobile && isOpen,
      "md:relative absolute z-50": true,
    }
  );

  useEffect(() => {
    if (isMobile && isOpen) {
      const handleEscape = (e: KeyboardEvent) => {
        if (e.key === "Escape") {
          onClose();
        }
      };
      document.addEventListener("keydown", handleEscape);
      return () => document.removeEventListener("keydown", handleEscape);
    }
  }, [isMobile, isOpen, onClose]);

  return (
    <aside className={sidebarClasses} data-testid="sidebar">
      <div className="p-6 border-b border-sidebar-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-sidebar-primary rounded-lg flex items-center justify-center">
            <Package2 className="text-sidebar-primary-foreground text-sm" size={16} />
          </div>
          {(!isCollapsed || isMobile) && (
            <div className="sidebar-text">
              <h1 className="text-lg font-semibold text-sidebar-foreground">RentTrack</h1>
              <p className="text-xs text-muted-foreground">Inventory Management</p>
            </div>
          )}
        </div>
      </div>
      
      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => isMobile && onClose()}
              className={cn(
                "flex items-center space-x-3 px-3 py-2 rounded-md transition-colors",
                {
                  "bg-sidebar-accent text-sidebar-accent-foreground font-medium": isActive,
                  "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground": !isActive,
                  "justify-center": isCollapsed && !isMobile,
                }
              )}
              data-testid={`nav-${item.href.slice(1) || "dashboard"}`}
            >
              <Icon className="w-5 h-5" />
              {(!isCollapsed || isMobile) && (
                <span className="sidebar-text">{item.label}</span>
              )}
            </Link>
          );
        })}
      </nav>
      
      <div className="p-4 border-t border-sidebar-border">
        <div className={cn(
          "flex items-center px-3 py-2",
          { "justify-center": isCollapsed && !isMobile }
        )}>
          <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
            <User className="text-secondary-foreground text-sm" size={16} />
          </div>
          {(!isCollapsed || isMobile) && (
            <div className="sidebar-text ml-3">
              <p className="text-sm font-medium text-sidebar-foreground">John Doe</p>
              <p className="text-xs text-muted-foreground">Manager</p>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
}

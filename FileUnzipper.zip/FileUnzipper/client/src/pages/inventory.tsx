import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Search, AlertTriangle, Package } from "lucide-react";
import { api } from "@/lib/api";
import { ProductWithCategory } from "@/types";

export default function Inventory() {
  const [searchTerm, setSearchTerm] = useState("");

  const { data: products, isLoading } = useQuery<ProductWithCategory[]>({
    queryKey: ["/api/products"],
    queryFn: api.getProducts,
  });

  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
    queryFn: api.getCategories,
  });

  const filteredProducts = products?.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.model?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const lowStockProducts = products?.filter(p => p.currentStock <= p.minStock) || [];

  const getStockStatus = (product: ProductWithCategory) => {
    if (product.currentStock === 0) {
      return { variant: "destructive" as const, text: "Out of Stock", className: "bg-red-100 text-red-800" };
    }
    if (product.currentStock <= product.minStock) {
      return { variant: "secondary" as const, text: "Low Stock", className: "bg-yellow-100 text-yellow-800" };
    }
    return { variant: "default" as const, text: "In Stock", className: "bg-green-100 text-green-800" };
  };

  if (isLoading) {
    return (
      <MainLayout 
        title="Estoque" 
        subtitle="Gerencie seus equipamentos e suprimentos"
      >
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-10 w-32" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <Skeleton className="h-16 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="grid gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-20 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout 
      title="Estoque" 
      subtitle="Gerencie seus equipamentos e suprimentos"
    >
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold" data-testid="text-inventory-title">My Inventory</h1>
            <p className="text-muted-foreground" data-testid="text-inventory-subtitle">
              Manage your equipment and supplies
            </p>
          </div>
          <Button data-testid="button-add-inventory">
            <Plus className="mr-2 h-4 w-4" />
            Add Item
          </Button>
        </div>

        {/* Inventory Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card data-testid="card-total-items">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Package className="text-blue-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Items</p>
                  <p className="text-xl font-bold">{products?.length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card data-testid="card-low-stock">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <AlertTriangle className="text-yellow-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Low Stock</p>
                  <p className="text-xl font-bold text-yellow-600">{lowStockProducts.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card data-testid="card-categories">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                  <Package className="text-green-600" size={16} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Categories</p>
                  <p className="text-xl font-bold">{categories?.length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Input
            type="search"
            placeholder="Search inventory..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pr-10"
            data-testid="input-search-inventory"
          />
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        </div>

        {/* Low Stock Alert */}
        {lowStockProducts.length > 0 && (
          <Card className="border-yellow-200 bg-yellow-50 dark:bg-yellow-950/20" data-testid="card-low-stock-alert">
            <CardContent className="p-4">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="text-yellow-600 mt-0.5" size={20} />
                <div>
                  <h3 className="text-sm font-medium text-yellow-800 dark:text-yellow-200">
                    {lowStockProducts.length} items need attention
                  </h3>
                  <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-1">
                    These items are running low or out of stock
                  </p>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {lowStockProducts.slice(0, 3).map((product) => (
                      <span 
                        key={product.id} 
                        className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded"
                        data-testid={`low-stock-item-${product.id}`}
                      >
                        {product.name}
                      </span>
                    ))}
                    {lowStockProducts.length > 3 && (
                      <span className="text-xs text-yellow-600">
                        +{lowStockProducts.length - 3} more
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Inventory List */}
        <div className="grid gap-4">
          {filteredProducts?.length === 0 && searchTerm ? (
            <Card data-testid="no-search-results">
              <CardContent className="p-8 text-center">
                <Search className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
                <h3 className="text-sm font-medium">No items found</h3>
                <p className="text-xs text-muted-foreground">
                  Try adjusting your search terms
                </p>
              </CardContent>
            </Card>
          ) : products?.length === 0 ? (
            <Card data-testid="empty-inventory">
              <CardContent className="p-12 text-center">
                <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No inventory items</h3>
                <p className="text-muted-foreground mb-4">
                  Start by adding your equipment and supplies
                </p>
                <Button data-testid="button-first-item">
                  <Plus className="mr-2 h-4 w-4" />
                  Add First Item
                </Button>
              </CardContent>
            </Card>
          ) : (
            filteredProducts?.map((product) => {
              const stockStatus = getStockStatus(product);

              return (
                <Card 
                  key={product.id} 
                  className="hover:shadow-md transition-shadow"
                  data-testid={`card-product-${product.id}`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-4 flex-1">
                        <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center">
                          <Package className="text-secondary-foreground" size={20} />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-1">
                            <h3 className="text-lg font-semibold" data-testid={`text-product-name-${product.id}`}>
                              {product.name}
                            </h3>
                            <Badge {...stockStatus}>{stockStatus.text}</Badge>
                            {product.category && (
                              <span 
                                className="text-xs px-2 py-1 rounded-full"
                                style={{ 
                                  backgroundColor: product.category.color + "20",
                                  color: product.category.color 
                                }}
                                data-testid={`badge-category-${product.id}`}
                              >
                                {product.category.name}
                              </span>
                            )}
                          </div>
                          {product.description && (
                            <p className="text-sm text-muted-foreground mb-2" data-testid={`text-description-${product.id}`}>
                              {product.description}
                            </p>
                          )}
                          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm text-muted-foreground">
                            <div>
                              <p className="font-medium text-foreground">Current Stock</p>
                              <p className={stockStatus.variant === "destructive" ? "text-red-600" : 
                                         stockStatus.variant === "secondary" ? "text-yellow-600" : "text-green-600"}
                                 data-testid={`text-stock-${product.id}`}>
                                {product.currentStock} units
                              </p>
                            </div>
                            <div>
                              <p className="font-medium text-foreground">Min. Stock</p>
                              <p data-testid={`text-min-stock-${product.id}`}>{product.minStock} units</p>
                            </div>
                            <div>
                              <p className="font-medium text-foreground">Model</p>
                              <p data-testid={`text-model-${product.id}`}>{product.model || "N/A"}</p>
                            </div>
                            <div>
                              <p className="font-medium text-foreground">Unit Cost</p>
                              <p data-testid={`text-cost-${product.id}`}>
                                {product.unitCost ? `$${product.unitCost}` : "N/A"}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2 ml-4">
                        <Button variant="outline" size="sm" data-testid={`button-edit-${product.id}`}>
                          Edit
                        </Button>
                        <Button variant="outline" size="sm" data-testid={`button-adjust-stock-${product.id}`}>
                          Adjust Stock
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>
      </div>
    </MainLayout>
  );
}

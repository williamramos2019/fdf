// Local type definitions to replace shared schema imports
export interface User {
  id: string;
  username: string;
  name: string;
  email: string;
  role: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  color: string;
  createdAt: string;
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson?: string;
  email?: string;
  phone?: string;
  address?: string;
  notes?: string;
  isActive: boolean;
  createdAt: string;
}

export interface Product {
  id: string;
  name: string;
  description?: string;
  model?: string;
  serialNumber?: string;
  categoryId?: string;
  currentStock: number;
  minStock: number;
  unitCost?: string;
  isActive: boolean;
  createdAt: string;
}

export interface Rental {
  id: string;
  productId?: string;
  supplierId?: string;
  quantity: number;
  dailyRate: string;
  startDate: string;
  endDate: string;
  returnedDate?: string;
  totalCost?: string;
  status: string;
  notes?: string;
  createdAt: string;
}

export interface InventoryMovement {
  id: string;
  productId?: string;
  type: string;
  quantity: number;
  reason?: string;
  reference?: string;
  createdAt: string;
}

// Form types
export interface CreateUserForm {
  username: string;
  password: string;
  name: string;
  email: string;
  role?: string;
}

export interface CreateCategoryForm {
  name: string;
  description?: string;
  color?: string;
}

export interface CreateSupplierForm {
  name: string;
  contactPerson?: string;
  email?: string;
  phone?: string;
  address?: string;
  notes?: string;
  isActive?: boolean;
}

export interface CreateProductForm {
  name: string;
  description?: string;
  model?: string;
  serialNumber?: string;
  categoryId?: string;
  currentStock?: number;
  minStock?: number;
  unitCost?: string;
  isActive?: boolean;
}

export interface CreateRentalForm {
  productId?: string;
  supplierId?: string;
  quantity?: number;
  dailyRate: string;
  startDate: string;
  endDate: string;
  returnedDate?: string;
  status?: string;
  notes?: string;
}

export interface CreateInventoryMovementForm {
  productId?: string;
  type: string;
  quantity: number;
  reason?: string;
  reference?: string;
}

// Extended types for dashboard
export interface DashboardStats {
  activeRentals: number;
  monthlyExpenses: string;
  inventoryItems: number;
  suppliers: number;
  overdueRentals: number;
  lowStockItems: number;
}

export interface RentalWithDetails extends Rental {
  product?: Product;
  supplier?: Supplier;
}

export interface ProductWithCategory extends Product {
  category?: Category;
}
